class {{ global_name }} {

}

export default new {{global_name}}()